<?php
// Heading
$_['heading_title']     = '下载文件';

// Text
$_['text_account']      = '账户';
$_['text_downloads']    = '下载文件';
$_['text_empty']        = '尚无含有下载文件的订单！';

// Column
$_['column_order_id']   = '订单号 ID';
$_['column_name']       = '姓名';
$_['column_size']       = '大小';
$_['column_date_added'] = '添加日期';