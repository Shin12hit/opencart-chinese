<?php
// Heading
$_['heading_title']    = '推广跟踪';

// Text
$_['text_account']     = '帐户';
$_['text_description'] = '如要确保从你推荐的会员中获取佣金，您需要将跟踪码放到分享的网站链接里面。您可以利用如下的工具生成网站 %s 的链接。';

// Entry
$_['entry_code']       = '您的跟踪码';
$_['entry_generator']  = '跟踪链接生成器';
$_['entry_link']       = '跟踪链接';

// Help
$_['help_generator']  = '输入你想生成的链接的商品名称';