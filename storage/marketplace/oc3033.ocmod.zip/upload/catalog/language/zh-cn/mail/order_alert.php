<?php
// Text
$_['text_subject']      = '%s - 订单 %s';
$_['text_received']     = '您收到一订单。';
$_['text_order_id']     = '订单号 ID:';
$_['text_date_added']   = '添加日期:';
$_['text_order_status'] = '订单状态:';
$_['text_product']      = '商品';
$_['text_total']        = '总计';
$_['text_comment']      = '订单备注为:';
