<?php
// Text
$_['text_subject']  = '%s - 推广佣金';
$_['text_received'] = '祝贺！您通过 %s 的推广功能获得了一笔推广佣金';
$_['text_amount']   = '您收到了:';
$_['text_total']    = '目前总佣金金额为:';