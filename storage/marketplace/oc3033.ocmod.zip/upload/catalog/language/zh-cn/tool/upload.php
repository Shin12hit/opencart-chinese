<?php
// Text
$_['text_upload']    = '文件已成功上传！';

// Error
$_['error_filename'] = '文件名必须为 3 - 64字符！';
$_['error_filetype'] = '无效文件类型！';
$_['error_upload']   = '必须上传文件！';
