<?php
// Text
$_['text_title']       = '到店自取';
$_['text_description'] = '到本商店自取';