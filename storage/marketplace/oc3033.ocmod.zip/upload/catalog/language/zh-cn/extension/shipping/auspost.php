<?php
// Text
$_['text_title']    = '澳大利亚邮政';
