<?php
// Heading
$_['heading_title'] = '使用代金券';

// Text
$_['text_voucher']  = '代金券 (%s)';
$_['text_success']  = '成功: 已应用代金券！';

// Entry
$_['entry_voucher'] = '输入代金券码';

// Error
$_['error_voucher'] = '警告: 代金券无效或已用完！';
$_['error_empty']   = '警告: 请输入代金券码！';