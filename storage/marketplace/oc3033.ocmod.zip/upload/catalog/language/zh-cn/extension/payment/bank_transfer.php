<?php
// Text
$_['text_title']				= '银行转账';
$_['text_instruction']			= '银行转账信息';
$_['text_description']			= '请将总金额转账至如下银行账号。';
$_['text_payment']				= '收到款项后配送货物。';