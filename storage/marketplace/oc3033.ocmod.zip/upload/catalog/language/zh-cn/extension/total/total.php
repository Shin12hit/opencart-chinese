<?php
// Text
$_['text_total'] = '总计';