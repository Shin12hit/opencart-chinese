<?php
// Heading
$_['heading_title'] = '选择网店';

// Text
$_['text_default']  = '默认';
$_['text_store']    = '选择希望访问的网店。';