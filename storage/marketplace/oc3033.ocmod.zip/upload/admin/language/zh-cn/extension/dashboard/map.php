<?php

// Heading
$_['heading_title'] = '世界地图';

// Text
$_['text_extension']   = '扩展功能';
$_['text_success']     = 'Success: You have modified dashboard map!';
$_['text_edit']        = 'Edit Dashboard Map';
$_['text_order']    = '订单数量';
$_['text_sale']     = '销售额';
// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';
$_['entry_width']      = '宽度';
// Error
$_['error_permission'] = '警告: 无权限修改仪表盘世界地图!';