<?php

// Heading
$_['heading_title'] = "广告";


// Columns
$_['column_name']   = "广告名称";
$_['column_status'] = "状态";
$_['column_action'] = "操作";


// Text
$_['text_success']   = "<strong>成功:</strong> 已修改广告！";

// Error
$_['error_adblock'] = "好像您正在使用广告封锁器。为了使用本广告区域，请在OpenCart管理面板找哦哦那个关闭您的广告封锁器。";
