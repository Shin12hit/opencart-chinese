<?php
// Heading
$_['heading_title']    = '会员账户';

//Text
$_['text_extension']   = '扩展功能';
$_['text_success']     = '成功: 已修改会员账户模组！';
$_['text_edit']        = '编辑会员账户模组 - (在线教程: <a href="http://www.mycncart.com/blog-110.html" target="_blank">http://www.mycncart.com/blog-110.html</a>)';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 无权限修改会员账户模组！';