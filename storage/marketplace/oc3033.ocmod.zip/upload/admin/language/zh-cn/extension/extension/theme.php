<?php
// Heading
$_['heading_title']    = '模板主题';

// Text
$_['text_success']     = '成功: 已修改模板主题！';
$_['text_list']        = '模板主题列表';

// Column
$_['column_name']      = '模板主题名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 无权限修改模板主题！';