<?php
// Heading
$_['heading_title']  = '未发现该页面Page Not Found!';

// Text
$_['text_not_found'] = '该页面不存在，如果持续存在此问题，请联系网站管理员解决。The page you are looking for could not be found!';