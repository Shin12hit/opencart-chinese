<?php
// Text
$_['text_subject'] = '%s - 帐号被拒绝';
$_['text_welcome'] = '欢迎在 %s 进行注册!';
$_['text_denied']  = '抱歉您的申请被拒绝，更多信息您可以通过这里联系网店管理员:';
$_['text_thanks']  = '感谢';
