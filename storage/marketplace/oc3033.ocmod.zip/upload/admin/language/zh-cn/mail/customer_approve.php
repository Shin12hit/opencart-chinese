<?php
// Text
$_['text_subject'] = '%s - 帐号已被激活!';
$_['text_welcome'] = '欢迎在 %s 注册!';
$_['text_login']   = '帐号已激活，您可以在如下地址使用电邮和密码进行登录:';
$_['text_service'] = '一旦登录，你可以访问其他服务，包括评论过往订单，打印发票，编辑帐号信息等。';
$_['text_thanks']  = '感谢';