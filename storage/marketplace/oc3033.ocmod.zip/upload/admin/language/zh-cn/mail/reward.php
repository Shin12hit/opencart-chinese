<?php
// Text
$_['text_subject']  = '%s - 奖励积分';
$_['text_received'] = '获得了 %s 奖励积分！';
$_['text_total']    = '目前总奖励积分为 %s。';