<?php
// Text
$_['text_subject']  = '%s - 推广佣金';
$_['text_received'] = '获得了 %s 推广佣金!';
$_['text_total']    = '目前总推广佣金为 %s。';
$_['text_credit']   = '推广佣金可以在您下一次购买时进行抵扣。';