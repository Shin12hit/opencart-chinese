<?php
// Text
$_['text_footer']  = '技术支持 <a href="http://www.mycncart.com">MyCnCart</a>&nbsp;&nbsp;<a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' 版权所有。';
$_['text_version'] = '版本 %s';