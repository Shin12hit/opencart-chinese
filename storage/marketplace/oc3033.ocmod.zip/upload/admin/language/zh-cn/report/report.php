<?php
// Heading
$_['heading_title'] = '报告';

// Text
$_['text_success']  = '成功: 已修改报告！';
$_['text_list']     = '报告列表';
$_['text_type']     = '选择报告类型 - (在线教程: <a href="http://www.mycncart.com/blog-133.html" target="_blank">http://www.mycncart.com/blog-133.html</a>)';
$_['text_filter']   = '筛选';